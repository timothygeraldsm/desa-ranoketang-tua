import GlitchPortfolio from "../portfolio"

export default function Page() {
  return <GlitchPortfolio />
}
